package org.cap.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {	
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		List<String> mobilenumbers = new ArrayList<String>();
		mobilenumbers.add("9502470889");
		mobilenumbers.add("8668102509");
		Customer customer = new Customer(1234, "Jack", LocalDate.now(), mobilenumbers);
		entityManager.persist(customer);
		
		CustomerAccount ca = new CustomerAccount();
		ca.setName("Ramesh");
		ca.setMobileNumber("9502470889");
		ca.setAccountNumber("123456");
		ca.setAccountType("savings");
		ca.setAccountOpenDate(LocalDate.now());
		entityManager.persist(ca);
		CustomerAccount catwo = new CustomerAccount();
		catwo.setName("Ramesh 2");
		catwo.setMobileNumber("8668102509");
		catwo.setAccountNumber("12345");
		catwo.setAccountType("savings");
		catwo.setAccountOpenDate(LocalDate.now());
		entityManager.persist(catwo);
		transaction.commit();
	}
}
