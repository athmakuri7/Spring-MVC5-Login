package playlist;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		int carid = Integer.parseInt(scr.next());
		String carmileage = scr.next();
		scr.close();
		switch (carid) {
		case 0:
			WagonR wr = new WagonR(false, "4", carmileage);
			String sdn = wr.getIsSedan() ? "is" : " is not";
			System.out.println("A WagonR "+sdn+" Sedan, is "+wr.getSeats()+"-seater, and has a mileage of around "+wr.getMileage()+" kmpl.");
			break;
		case 1:
			HondaCity hc = new HondaCity(true, "4", carmileage);
			String sdn1 = hc.getIsSedan() ? "is" : " is not";
			System.out.println("A Hondacity "+sdn1+" Sedan, is "+hc.getSeats()+"-seater, and has a mileage of around "+hc.getMileage()+" kmpl.");
			break;
		case 2:
			InnovaCrysta ic = new InnovaCrysta(true, "6", carmileage);
			String sdn2 = ic.getIsSedan() ? "is" : " is not";
			System.out.println("A Innova "+sdn2+" Sedan, is "+ic.getSeats()+"-seater, and has a mileage of around "+ic.getMileage()+" kmpl.");
			break;
		default:
			break;
		}

	}

}

class WagonR extends Car {
	
	String carmileage;

	public WagonR(boolean isSedan, String seats, String mileage) {
		super(isSedan, seats);
		this.carmileage = mileage;
	}

	@Override
	public String getMileage() {
		return this.carmileage;
	}

}

class HondaCity extends Car {

	String carmileage;
	
	public HondaCity(boolean isSedan, String seats, String mileage) {
		super(isSedan, seats);
		this.carmileage = mileage;
	}

	@Override
	public String getMileage() {
		return this.carmileage;
	}

}

class InnovaCrysta extends Car {

	String carmileage;
	
	public InnovaCrysta(boolean isSedan, String seats, String mileage) {
		super(isSedan, seats);
		this.carmileage = mileage;
	}

	@Override
	public String getMileage() {
		return this.carmileage;
	}

}