package playlist;

import java.util.Arrays;
import java.util.Scanner;

public class SearchSong {
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		String n = scr.next();
		String[] songsList = null;
		if(Integer.parseInt(n) > 100) {
			songsList = new String[100];
		} else {
			songsList = new String[Integer.parseInt(n)];
		}
		for(int i=0; i<songsList.length; i++) {
			songsList[i] = scr.next();
		}
		int currentIndex = Integer.parseInt(scr.next());
		String nextSong = scr.next();
		int nextSongIndex = Arrays.asList(songsList).indexOf(nextSong);
		if(nextSongIndex != -1 && nextSongIndex > currentIndex) {
			System.out.println("> : " + (nextSongIndex-currentIndex));
		} else if(nextSongIndex != -1 && nextSongIndex < currentIndex) {
			System.out.println("< : " + (currentIndex-nextSongIndex));
		}
		scr.close();
	}
}
